import { View, Text } from 'react-native'

function Pickup() {
    return (
        <View>
            <Text>Chats</Text>
        </View>
    )
}

export default Pickup