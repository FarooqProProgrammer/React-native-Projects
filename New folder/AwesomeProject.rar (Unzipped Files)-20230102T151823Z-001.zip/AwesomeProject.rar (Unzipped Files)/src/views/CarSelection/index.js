import { View, Text } from 'react-native'

function Pickup() {
    return (
        <View>
            <Text>Car Selection Screen</Text>
        </View>
    )
}

export default Pickup