import { View, Text } from 'react-native'

function Pickup() {
    return (
        <View>
            <Text>Status</Text>
        </View>
    )
}

export default Pickup